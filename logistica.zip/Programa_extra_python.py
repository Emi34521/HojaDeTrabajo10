import networkx as nx
import numpy as np

CLIMAS = ["normal", "lluvia", "nieve", "tormenta"]

def leer_grafo(nombre_archivo, clima="normal"):
    G = nx.DiGraph()
    try:
        with open(nombre_archivo, "r") as f:
            for linea in f:
                partes = linea.strip().split(',')
                if len(partes) != 6:
                    print(f"Línea inválida: {linea.strip()}")
                    continue
                origen, destino = partes[0].lower(), partes[1].lower()
                try:
                    tiempos = list(map(int, partes[2:]))
                except ValueError:
                    print(f"Tiempos inválidos en la línea: {linea.strip()}")
                    continue
                peso = tiempos[CLIMAS.index(clima)]
                G.add_edge(origen, destino, weight=peso, tiempos=tiempos)
    except FileNotFoundError:
        print("Archivo no encontrado.")
    return G


def mostrar_matriz_adyacencia(G):
    nodos = list(G.nodes)
    n = len(nodos)
    matriz = np.full((n, n), np.inf)
    for i, u in enumerate(nodos):
        for j, v in enumerate(nodos):
            if G.has_edge(u, v):
                matriz[i][j] = G[u][v]["weight"]
    print("\nMatriz de Adyacencia:")
    print(f"{'':12}", *[f"{nodo:12}" for nodo in nodos])
    for i, fila in enumerate(matriz):
        print(f"{nodos[i]:12}", *[f"{(int(x) if x != np.inf else '∞'):>12}" for x in fila])
    return nodos, matriz

def floyd_warshall(G):
    return nx.floyd_warshall_predecessor_and_distance(G, weight="weight")

def obtener_camino(predecesores, origen, destino):
    if origen == destino:
        return [origen]
    camino = []
    while destino != origen:
        camino.insert(0, destino)
        destino = predecesores[origen].get(destino)
        if destino is None:
            return []
    camino.insert(0, origen)
    return camino

def centro_del_grafo(distancias):
    excentricidades = {}
    for nodo, destinos in distancias.items():
        excentricidades[nodo] = max(destinos.values(), default=float('inf'))
    centro = min(excentricidades, key=excentricidades.get)
    return centro

def modificar_grafo(G):
    print("\n1. Interrupción de tráfico\n2. Nueva conexión\n3. Cambiar clima de un arco")
    op = input("Elija una opción: ")
    if op == "1":
        c1 = input("Ciudad 1: ")
        c2 = input("Ciudad 2: ")
        if G.has_edge(c1, c2):
            G.remove_edge(c1, c2)
            print("Arco eliminado.")
    elif op == "2":
        c1 = input("Ciudad 1: ")
        c2 = input("Ciudad 2: ")
        try:
            tiempos = list(map(int, input("Ingrese los 4 tiempos separados por espacio (normal lluvia nieve tormenta): ").split()))
            if len(tiempos) != 4:
                raise ValueError
        except ValueError:
            print("Formato incorrecto.")
            return
        G.add_edge(c1, c2, weight=tiempos[0], tiempos=tiempos)
        print("Arco agregado.")
    elif op == "3":
        c1 = input("Ciudad 1: ")
        c2 = input("Ciudad 2: ")
        clima = input("Clima actual (normal, lluvia, nieve, tormenta): ").strip().lower()
        if G.has_edge(c1, c2) and clima in CLIMAS:
            pesos = G[c1][c2]["tiempos"]
            G[c1][c2]["weight"] = pesos[CLIMAS.index(clima)]
            print("Peso actualizado por clima.")
        else:
            print("Ciudad o clima no válidos.")
    else:
        print("Opción no válida.")
# Aquí simplemente se llama al menú principal
def menu():
    clima = "normal"
    G = leer_grafo("logistica.txt", clima)
    if len(G) == 0:
        print("No se pudo cargar el grafo. Verifique el archivo.")
        return
    while True:
        nodos, matriz = mostrar_matriz_adyacencia(G)
        predecesores, distancias = floyd_warshall(G)
        print("\nMenú:")
        print("1. Ruta más corta entre ciudades")
        print("2. Ciudad centro del grafo")
        print("3. Modificar grafo")
        print("4. Salir")
        op = input("Opción: ")

        if op == "1":
            o = input("Ciudad origen: ").strip().lower()
            d = input("Ciudad destino: ").strip().lower()
            if o in G and d in G:
                dist = distancias[o].get(d, float("inf"))
                if dist == float("inf"):
                    print("No hay ruta.")
                else:
                    camino = obtener_camino(predecesores, o, d)
                    print(f"Ruta más corta ({dist}): {' -> '.join(camino)}")
            else:
                print("Una de las ciudades no existe.")
        elif op == "2":
            centro = centro_del_grafo(distancias)
            print(f"Centro del grafo: {centro}")
        elif op == "3":
            modificar_grafo(G)
        elif op == "4":
            print("Programa finalizado.")
            break
        else:
            print("Opción inválida.")

# Ejecutar el programa
if __name__ == "__main__":
    menu()

